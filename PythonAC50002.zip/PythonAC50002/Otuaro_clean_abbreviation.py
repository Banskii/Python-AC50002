import re
from Otuaro_values_scoring import *


def clean(text):
    """
    clean trees name by removing apostrophes and non-letters splitting into words,
    converting to uppercase.
    """

    # Remove apostrophes, replace non-letter characters with spaces
    cleaned = re.sub(r"'", '', text)
    cleaned = re.sub(r'[^A-Za-z\s]', ' ', cleaned)

    # Split into words and convert to uppercase
    words = cleaned.upper().split()
    result = []
    for word in words:
        if word:
            result.append(word)
    return result


def generate_abbreviations(name, letter_values):
    """
    Generate possible three-letter abbreviations with consistent generation.
    """
    words = clean(name)

    # If not enough letters, return empty list
    if len(''.join(words)) < 3:
        return []

    abbreviations = set()  # Use a set to avoid duplicate abbreviations

    # For single word
    if len(words) == 1:
        word = words[0]
        # Generate variations within the single word
        # Always use first letter as first letter of abbreviation
        first_letter = word[0]
        potential_seconds = word[1:] if len(word) > 1 else []
        potential_thirds = word[2:] if len(word) > 1 else []

        for second_letter in potential_seconds:
            for third_letter in potential_thirds:
                if second_letter != third_letter:
                    abbrev = first_letter + second_letter + third_letter
                    score = sum(letter_score(l, word, letter_values) for l in abbrev)
                    abbreviations.add((abbrev, score))  # Use set to ensure uniqueness

    # For two or more words
    else:
        # First letter of first word always used
        first_letter = words[0][0]

        # For two-word case
        if len(words) == 2:
            # First letters of both words
            second_letter = words[1][0]

            # Alternate letters from second word
            third_letter_options = list(set(words[1]) - {second_letter})

            for third_letter in third_letter_options[:2]:  # Limit to prevent too many variations
                abbrev = first_letter + second_letter + third_letter
                score = (letter_score(first_letter, words[0], letter_values) +
                         letter_score(second_letter, words[1], letter_values) +
                         letter_score(third_letter, words[1], letter_values))
                abbreviations.add((abbrev, score))  # Use set to ensure uniqueness

        # For three or more words
        else:
            # First letters of first two words
            second_letter = words[1][0]
            third_letter = words[2][0]

            abbrev = first_letter + second_letter + third_letter
            score = (letter_score(first_letter, words[0], letter_values) +
                     letter_score(second_letter, words[1], letter_values) +
                     letter_score(third_letter, words[2], letter_values))
            abbreviations.add((abbrev, score))  # Use set to ensure uniqueness

    return list(abbreviations)  # Convert the set back to a list to preserve the format
