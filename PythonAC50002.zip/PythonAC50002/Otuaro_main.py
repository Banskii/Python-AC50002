import os
from Otuaro_clean_abbreviation import *
from Otuaro_values_scoring import *

def main():
    # Prompt for input filename with validation
    while True:
        input_filename = input("Enter the input filename (must end in .txt): ")

        # Validate input filename
        if not input_filename.endswith('.txt'):
            print("Error: Input file must have .txt extension")
        else:
            # Check if the file exists
            if os.path.isfile(input_filename):
                break  # Exit the loop if file exists
            else:
                print(f"Error: Input file {input_filename} not found. Please check the file path and try again.")

    # Determine output filename (using a placeholder surname)
    surname = input("Enter your surname:")
    output_filename = f"{surname}_{input_filename.replace('.txt', '_abbrevs.txt')}"

    # Read letter values
    letter_values = read_values()

    try:
        # Read input names
        with open(input_filename, 'r') as inputs:
            names = [line.strip() for line in inputs]

        # Track abbreviations across all names
        global_abbrevs = set()
        name_abbrevs = {}

        # Find abbreviations for each name
        for name in names:
            # Generate abbreviations
            abbrevs = generate_abbreviations(name, letter_values)

            # Remove abbreviations that appear in multiple names
            specific_abbrevs = []
            for abbrev, score in abbrevs:
                if abbrev not in global_abbrevs:
                    specific_abbrevs.append((abbrev, score))

            # Track global abbreviations
            global_abbrevs.update(map(lambda x: x[0], specific_abbrevs))

            # Find the lowest score abbreviations
            if specific_abbrevs:
                min_score = min(score for _, score in specific_abbrevs)
                name_abbrevs[name] = [abbrev for abbrev, score in specific_abbrevs
                                      if score == min_score]

            else:
                name_abbrevs[name] = []

        # Write output
        with open(output_filename, 'w') as outfile:
            for name, abbrevs in name_abbrevs.items():
                outfile.write(f"{name}\n")
                outfile.write(f"{' '.join(abbrevs) if abbrevs else ''}\n")

        print(f"Abbreviations written to {output_filename}")

    except Exception as e:
        print(f"An error occurred: {e}")


# Allow the script to be run directly or imported
if __name__ == "__main__":
    main()
