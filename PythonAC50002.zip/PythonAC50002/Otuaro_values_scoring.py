def read_values(filename='values.txt'):
    values = {}
    """
    Read letter values from values.txt file and return the contents in a dictionary. 
    """
    with open(filename, 'r') as file:
        for line in file:
            word, value = line.split()
            values[word] = int(value)
    return values


def letter_score(letter: str, word: str, letter_values: dict):
    """
    Calculate score for a letter based on its position and letter value.
    """
    # First letter of word gets 0
    if letter == word[0]:
        return 0

    # Last letter of word gets 5, or 20 if E
    if letter == word[-1]:
        return 20 if letter == 'E' else 5

    # Calculate position score
    position = word.index(letter)
    if position == 1:
        position_score = 1
    elif position == 2:
        position_score = 2
    else:
        position_score = 3

    # Get letter value, defaulting to 0 if not found
    letter_value = letter_values.get(letter, 0)

    return position_score + letter_value